import { useState } from 'react';
import { GraduationCap } from 'lucide-react';
import { FileUpload } from '@/components/resume-parser/FileUpload';
import { ProgramCard } from '@/components/resume-parser/ProgramCard';
import { CertificateCard } from '@/components/resume-parser/CertificateCard';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { analyzeResume } from '@/lib/utils/analyzeResume';
import { triggerConfetti } from '@/lib/utils/confetti';
import type { ProgramRecommendation, CertificateRecommendation } from '@/lib/utils/analyzeResume';

function App() {
  const [fileContent, setFileContent] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recommendations, setRecommendations] = useState<{
    programs: ProgramRecommendation[];
    certificates: CertificateRecommendation[];
  } | null>(null);
  const [error, setError] = useState('');

  const handleFileUpload = (content: string) => {
    setFileContent(content);
    handleAnalyze(content);
  };

  const handleAnalyze = async (content: string) => {
    setIsAnalyzing(true);
    setError('');

    try {
      const results = analyzeResume(content);
      setRecommendations(results);
      if (results.programs.length > 0 || results.certificates.length > 0) {
        triggerConfetti();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error analyzing resume');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1E3877]/5 to-white p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <GraduationCap className="h-16 w-16 text-[#1E3877]" />
          </div>
          <h1 className="text-4xl font-bold text-[#1E3877] mb-2">Find Your Perfect Program</h1>
          <p className="text-lg text-gray-600">
            Upload your resume or paste your experience to get personalized program and certificate recommendations
          </p>
        </div>

        {/* File Upload */}
        <FileUpload onFileUpload={handleFileUpload} onError={setError} />

        {/* Text Input */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Or paste your experience
          </label>
          <textarea
            className="w-full h-40 p-4 rounded-xl border border-gray-200 focus:border-[#E84A27] focus:ring-[#E84A27]"
            placeholder="Paste your resume or describe your experience..."
            value={fileContent}
            onChange={(e) => setFileContent(e.target.value)}
          />
        </div>

        {error && (
          <Alert variant="destructive" className="bg-red-50 border border-red-200 text-red-800">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <button
          onClick={() => handleAnalyze(fileContent)}
          disabled={isAnalyzing || !fileContent.trim()}
          className="w-full py-3 bg-[#E84A27] text-white rounded-xl font-medium hover:bg-[#E84A27]/90 transition-colors disabled:bg-[#E84A27]/50"
        >
          {isAnalyzing ? 'Analyzing your profile...' : 'Get Recommendations'}
        </button>

        {/* Results */}
        {recommendations && (recommendations.programs.length > 0 || recommendations.certificates.length > 0) && (
          <Tabs defaultValue="programs" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="programs">Degree Programs</TabsTrigger>
              <TabsTrigger value="certificates">Online Certificates</TabsTrigger>
            </TabsList>
            
            <TabsContent value="programs">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-[#1E3877] text-center">
                  Your Recommended Programs
                </h2>
                <div className="grid gap-6 md:grid-cols-2">
                  {recommendations.programs.map((rec, index) => (
                    <ProgramCard key={rec.program} recommendation={rec} index={index} />
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="certificates">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-[#1E3877] text-center">
                  Your Recommended Certificates
                </h2>
                <div className="grid gap-6 md:grid-cols-2">
                  {recommendations.certificates.map((rec, index) => (
                    <CertificateCard key={rec.name} recommendation={rec} index={index} />
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}

export default App;