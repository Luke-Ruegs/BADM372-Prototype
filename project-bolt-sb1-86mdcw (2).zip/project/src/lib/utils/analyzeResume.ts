import { programs } from '../constants/programs';
import { certificates } from '../constants/certificates';
import { processText, calculateSemanticSimilarity, findMatchingSkills, extractSkillLevels } from './nlpProcessor';

export type ProgramRecommendation = {
  program: string;
  confidence: number;
  matches: string[];
  matchExplanations: string[];
  personalizedReason: string;
  duration: string;
  requirements: string;
  careers: string[];
  description: string;
  specializations?: string[];
  concentrations?: string[];
  coreCourses?: string[];
  startDates: string[];
};

export type CertificateRecommendation = {
  name: string;
  confidence: number;
  matches: string[];
  matchExplanations: string[];
  personalizedReason: string;
  duration: string;
  format: string;
  timeCommitment: string;
  topics: string[];
  targetAudience: string;
};

export type AnalysisResult = {
  programs: ProgramRecommendation[];
  certificates: CertificateRecommendation[];
};

function generatePersonalizedReason(
  resumeText: string,
  programInfo: any,
  matches: string[],
  skillLevels: Map<string, string>
): string {
  const processedResume = processText(resumeText);
  const reasons: string[] = [];

  // Check for experience level
  let hasAdvancedSkills = false;
  let hasRelevantExperience = false;
  matches.forEach(skill => {
    const level = skillLevels.get(skill);
    if (level === 'advanced' || level === 'expert') {
      hasAdvancedSkills = true;
    }
    if (resumeText.toLowerCase().includes(`experience in ${skill}`)) {
      hasRelevantExperience = true;
    }
  });

  // Add experience-based reason
  if (hasAdvancedSkills) {
    reasons.push(`Your advanced expertise in ${matches.slice(0, 2).join(' and ')} aligns perfectly with this program's curriculum`);
  } else if (hasRelevantExperience) {
    reasons.push(`Your practical experience in ${matches.slice(0, 2).join(' and ')} provides a strong foundation for this program`);
  }

  // Add career alignment reason
  const careerMatches = programInfo.careers.filter(career =>
    processedResume.concepts.some(concept =>
      career.toLowerCase().includes(concept.toLowerCase())
    )
  );
  if (careerMatches.length > 0) {
    reasons.push(`This program directly supports your career goals in ${careerMatches[0]}`);
  }

  // Add skill development reason
  const missingKeySkills = programInfo.keywords.filter(keyword =>
    !matches.includes(keyword) && 
    programInfo.keywords.indexOf(keyword) < 5
  ).slice(0, 2);
  if (missingKeySkills.length > 0) {
    reasons.push(`You'll develop crucial skills in ${missingKeySkills.join(' and ')}, complementing your existing expertise`);
  }

  // Add specialization/concentration reason
  if (programInfo.specializations || programInfo.concentrations) {
    const specs = programInfo.specializations || programInfo.concentrations;
    const matchingSpec = specs.find(spec =>
      processedResume.concepts.some(concept =>
        spec.toLowerCase().includes(concept.toLowerCase())
      )
    );
    if (matchingSpec) {
      reasons.push(`The ${matchingSpec} specialization aligns with your background and interests`);
    }
  }

  return reasons.join('. ');
}

export function analyzeResume(text: string): AnalysisResult {
  if (!text || typeof text !== 'string') {
    throw new Error('Invalid input: Resume text is required');
  }

  const processedText = text.toLowerCase();
  const skillLevels = extractSkillLevels(text);
  const programResults: ProgramRecommendation[] = [];
  const certificateResults: CertificateRecommendation[] = [];

  try {
    // Analyze for programs
    Object.entries(programs).forEach(([programName, details]) => {
      const { matches, scores } = findMatchingSkills(text, details.keywords);
      
      if (matches.length > 0) {
        const similarity = calculateSemanticSimilarity(
          text,
          [
            ...details.keywords,
            ...details.careers,
            details.description,
            ...(details.coreCourses || []),
            ...(details.specializations || []),
            ...(details.concentrations || [])
          ].join(' ')
        );

        const baseScore = similarity * 100;
        let finalScore = baseScore;

        // Generate match explanations
        const matchExplanations: string[] = [];
        matches.forEach(match => {
          const level = skillLevels.get(match) || 'experience';
          matchExplanations.push(
            `Your ${level} in ${match} is highly relevant for this program`
          );
        });

        // Additional scoring factors
        if (text.includes('leadership') && details.keywords.includes('leadership')) {
          finalScore += 10;
          matchExplanations.push('Your leadership experience is valuable for this program');
        }

        if (text.includes('international') && details.keywords.includes('global')) {
          finalScore += 5;
          matchExplanations.push('Your international exposure aligns with the program\'s global focus');
        }

        // Generate personalized reason
        const personalizedReason = generatePersonalizedReason(text, details, matches, skillLevels);

        programResults.push({
          program: programName,
          confidence: Math.min(100, Math.round(finalScore)),
          matches,
          matchExplanations,
          personalizedReason,
          duration: details.duration,
          requirements: details.requirements,
          careers: details.careers,
          description: details.description,
          specializations: details.specializations,
          concentrations: details.concentrations,
          coreCourses: details.coreCourses,
          startDates: details.startDates
        });
      }
    });

    // Analyze for certificates
    Object.entries(certificates).forEach(([certName, details]) => {
      const { matches, scores } = findMatchingSkills(text, details.keywords);
      
      if (matches.length > 0) {
        const similarity = calculateSemanticSimilarity(
          text,
          [
            ...details.keywords,
            ...details.topics,
            details.targetAudience
          ].join(' ')
        );

        const baseScore = similarity * 100;
        let finalScore = baseScore;

        // Generate match explanations
        const matchExplanations: string[] = matches.map(match => {
          const level = skillLevels.get(match) || 'experience';
          return `Your ${level} in ${match} provides a strong foundation for this certificate`;
        });

        // Generate personalized reason
        const personalizedReason = generatePersonalizedReason(text, {
          ...details,
          careers: details.topics
        }, matches, skillLevels);

        certificateResults.push({
          name: certName,
          confidence: Math.min(100, Math.round(finalScore)),
          matches,
          matchExplanations,
          personalizedReason,
          duration: details.duration,
          format: details.format,
          timeCommitment: details.timeCommitment,
          topics: details.topics,
          targetAudience: details.targetAudience
        });
      }
    });

    return {
      programs: programResults.sort((a, b) => b.confidence - a.confidence),
      certificates: certificateResults.sort((a, b) => b.confidence - a.confidence)
    };
  } catch (error) {
    console.error('Error analyzing resume:', error);
    throw new Error('Failed to analyze resume content');
  }
}