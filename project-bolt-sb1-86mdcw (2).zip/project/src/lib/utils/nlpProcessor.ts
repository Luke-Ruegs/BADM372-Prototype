// Simple text preprocessing
function preprocessText(text: string): string[] {
  return text.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2);
}

// Calculate term frequency
function tf(term: string, doc: string[]): number {
  const termCount = doc.filter(word => word === term).length;
  return termCount / doc.length;
}

// Calculate inverse document frequency
function idf(term: string, docs: string[][]): number {
  const docsWithTerm = docs.filter(doc => doc.includes(term)).length;
  return Math.log(docs.length / (1 + docsWithTerm));
}

// Calculate TF-IDF score
function tfidf(term: string, doc: string[], docs: string[][]): number {
  return tf(term, doc) * idf(term, docs);
}

export function processText(text: string): {
  tokens: string[];
  keywords: string[];
  concepts: string[];
} {
  const tokens = preprocessText(text);
  
  // Extract keywords (unique tokens)
  const keywords = Array.from(new Set(tokens));
  
  // Extract concepts (meaningful phrases)
  const concepts = [];
  for (let i = 0; i < tokens.length - 1; i++) {
    concepts.push(`${tokens[i]} ${tokens[i + 1]}`);
  }
  
  return {
    tokens,
    keywords: keywords.slice(0, 20),
    concepts: Array.from(new Set(concepts)).slice(0, 20)
  };
}

export function calculateSemanticSimilarity(text1: string, text2: string): number {
  const tokens1 = preprocessText(text1);
  const tokens2 = preprocessText(text2);
  
  const uniqueTerms = Array.from(new Set([...tokens1, ...tokens2]));
  const allDocs = [tokens1, tokens2];
  
  let similarity = 0;
  uniqueTerms.forEach(term => {
    const score1 = tfidf(term, tokens1, allDocs);
    const score2 = tfidf(term, tokens2, allDocs);
    similarity += score1 * score2;
  });
  
  return similarity;
}

export function findMatchingSkills(resumeText: string, programKeywords: string[]): {
  matches: string[];
  scores: { [key: string]: number };
} {
  const resumeTokens = preprocessText(resumeText);
  const matches: string[] = [];
  const scores: { [key: string]: number } = {};

  programKeywords.forEach(keyword => {
    const keywordTokens = preprocessText(keyword);
    const allDocs = [resumeTokens, keywordTokens];
    
    const score = keywordTokens.reduce((acc, term) => 
      acc + tfidf(term, resumeTokens, allDocs), 0);
    
    if (score > 0.01) {
      matches.push(keyword);
      scores[keyword] = score;
    }
  });

  return { matches, scores };
}

export function extractSkillLevels(text: string): Map<string, string> {
  const skillLevels = new Map<string, string>();
  const text_lower = text.toLowerCase();
  
  // Common skill level patterns
  const patterns = [
    { level: 'expert', patterns: ['expert', 'advanced', 'extensive'] },
    { level: 'intermediate', patterns: ['intermediate', 'proficient', 'experienced'] },
    { level: 'beginner', patterns: ['beginner', 'basic', 'familiar'] }
  ];
  
  // Extract skill levels from text
  const words = preprocessText(text);
  for (let i = 0; i < words.length; i++) {
    for (const { level, patterns: levelPatterns } of patterns) {
      if (levelPatterns.some(pattern => text_lower.includes(pattern + ' ' + words[i]))) {
        skillLevels.set(words[i], level);
      }
    }
  }
  
  return skillLevels;
}