import { getDocument, GlobalWorkerOptions, type PDFDocumentProxy } from 'pdfjs-dist';
import mammoth from 'mammoth';

// Configure PDF.js worker
GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js';

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const SUPPORTED_TYPES = {
  'text/plain': 'txt',
  'application/pdf': 'pdf',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx'
} as const;

type FileError = {
  code: string;
  message: string;
  details?: string;
};

export async function parseFile(file: File): Promise<string> {
  try {
    // Validate file existence
    if (!file) {
      throw createError('NO_FILE', 'No file provided');
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      throw createError(
        'FILE_TOO_LARGE',
        'File size exceeds 10MB limit',
        `File size: ${(file.size / 1024 / 1024).toFixed(2)}MB`
      );
    }

    // Handle different MIME types
    const fileType = Object.entries(SUPPORTED_TYPES).find(([mime]) => 
      file.type === mime || file.name.toLowerCase().endsWith(`.${SUPPORTED_TYPES[mime as keyof typeof SUPPORTED_TYPES]}`)
    );

    if (!fileType) {
      throw createError(
        'INVALID_FILE_TYPE',
        'Unsupported file type. Please upload a TXT, PDF, DOC, or DOCX file',
        `Provided type: ${file.type}`
      );
    }

    let text: string;

    // Parse file based on type
    switch (fileType[0]) {
      case 'text/plain':
        text = await parseTextFile(file);
        break;
      case 'application/pdf':
        text = await parsePDFFile(file);
        break;
      case 'application/msword':
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        text = await parseWordFile(file);
        break;
      default:
        throw createError('UNSUPPORTED_TYPE', 'Unsupported file type');
    }

    // Validate extracted text
    if (!text || text.trim().length === 0) {
      throw createError(
        'NO_CONTENT',
        'No readable text found in the document',
        'The file appears to be empty or contains no extractable text'
      );
    }

    // Clean and normalize text
    const normalizedText = normalizeText(text);

    // Validate normalized text
    if (!normalizedText || normalizedText.length < 50) {
      throw createError(
        'INSUFFICIENT_CONTENT',
        'The document contains too little text to analyze',
        'Please ensure your resume contains sufficient information'
      );
    }

    return normalizedText;
  } catch (error) {
    console.error('File parsing error:', error);
    if (error instanceof Error && 'code' in error) {
      throw error;
    }
    throw createError(
      'UNKNOWN_ERROR',
      'An unexpected error occurred while processing the file',
      error instanceof Error ? error.message : undefined
    );
  }
}

async function parseTextFile(file: File): Promise<string> {
  try {
    return await file.text();
  } catch (error) {
    throw createError(
      'TEXT_PARSE_ERROR',
      'Failed to read text file',
      error instanceof Error ? error.message : undefined
    );
  }
}

async function parsePDFFile(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await getDocument({ data: arrayBuffer }).promise;
    
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items
        .map((item: any) => item.str)
        .join(' ');
      fullText += pageText + '\n';
    }
    
    return fullText;
  } catch (error) {
    throw createError(
      'PDF_PARSE_ERROR',
      'Failed to parse PDF file',
      error instanceof Error ? error.message : undefined
    );
  }
}

async function parseWordFile(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    
    if (!result || !result.value) {
      throw createError(
        'WORD_INVALID',
        'Invalid or corrupted Word document'
      );
    }
    
    return result.value;
  } catch (error) {
    throw createError(
      'WORD_PARSE_ERROR',
      'Failed to parse Word document',
      error instanceof Error ? error.message : undefined
    );
  }
}

function normalizeText(text: string): string {
  return text
    .replace(/[\r\n]+/g, '\n')
    .replace(/[^\S\r\n]+/g, ' ')
    .replace(/[•●◦○]/g, '')
    .replace(/[^\x20-\x7E\n]/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function createError(code: string, message: string, details?: string): FileError & Error {
  const error = new Error(message) as FileError & Error;
  error.code = code;
  error.details = details;
  return error;
}