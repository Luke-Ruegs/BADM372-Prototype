import { programs } from '../constants/programs';
import { certificates } from '../constants/certificates';

// Calculate term frequency
function tf(term: string, doc: string): number {
  const words = doc.toLowerCase().split(/\s+/);
  const termCount = words.filter(word => word === term.toLowerCase()).length;
  return termCount / words.length;
}

// Calculate inverse document frequency
function idf(term: string, docs: string[]): number {
  const docsWithTerm = docs.filter(doc => 
    doc.toLowerCase().includes(term.toLowerCase())
  ).length;
  return Math.log(docs.length / (1 + docsWithTerm));
}

// Calculate TF-IDF score
function tfidf(term: string, doc: string, docs: string[]): number {
  return tf(term, doc) * idf(term, docs);
}

// Preprocess text to extract meaningful terms
function preprocessText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Calculate similarity score between two documents using TF-IDF
export function calculateSimilarity(doc1: string, doc2: string, allDocs: string[]): number {
  const terms = new Set([
    ...doc1.toLowerCase().split(/\s+/),
    ...doc2.toLowerCase().split(/\s+/)
  ]);

  let score = 0;
  terms.forEach(term => {
    const tfidf1 = tfidf(term, doc1, allDocs);
    const tfidf2 = tfidf(term, doc2, allDocs);
    score += tfidf1 * tfidf2;
  });

  return score;
}

// Generate document representation for a program or certificate
function generateDocumentText(item: any): string {
  return [
    ...(item.keywords || []),
    ...(item.coreCourses || []),
    ...(item.careers || []),
    item.description || '',
    ...(item.specializations || []),
    ...(item.concentrations || []),
    ...(item.topics || [])
  ].join(' ');
}

// Calculate match explanations based on TF-IDF scores
export function generateMatchExplanations(
  resumeText: string,
  itemText: string,
  keywords: string[],
  allDocs: string[]
): { explanations: string[]; scores: { [key: string]: number } } {
  const explanations: string[] = [];
  const scores: { [key: string]: number } = {};

  keywords.forEach(keyword => {
    const score = tfidf(keyword, resumeText, allDocs);
    if (score > 0) {
      scores[keyword] = score;
      const context = score > 0.05 ? 'strong' : score > 0.02 ? 'relevant' : 'some';
      explanations.push(
        `You have ${context} experience with ${keyword}, which is key for this program`
      );
    }
  });

  return { explanations, scores };
}

// Generate all documents for comparison
export function generateAllDocuments(): string[] {
  const allDocs = [
    ...Object.values(programs).map(generateDocumentText),
    ...Object.values(certificates).map(generateDocumentText)
  ];
  return allDocs.map(preprocessText);
}