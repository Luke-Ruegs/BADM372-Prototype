export const certificates = {
  "Business Analytics": {
    keywords: [
      "data", "analytics", "statistics", "data-driven", "business intelligence",
      "data analysis", "data visualization", "decision-making", "sql", "python",
      "tableau", "power bi", "metrics", "kpi", "reporting"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Analytics strategy, methods, and tools",
      "Analytic languages",
      "Data preparation and communication",
      "Business analytic mindset development"
    ],
    targetAudience: "Professionals looking to enhance their data-driven decision-making skills across various business disciplines"
  },
  "Digital Marketing": {
    keywords: [
      "marketing", "digital", "social media", "seo", "content marketing",
      "email marketing", "analytics", "campaigns", "advertising", "brand",
      "customer experience", "crm", "marketing automation", "conversion"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Latest digital marketing tools and techniques",
      "Data-driven decision-making in marketing",
      "Creation of effective, targeted campaigns"
    ],
    targetAudience: "Marketing professionals or those looking to transition into digital marketing roles"
  },
  "Entrepreneurship and Strategic Innovation": {
    keywords: [
      "entrepreneurship", "innovation", "startup", "business model",
      "strategy", "leadership", "venture", "product development",
      "market analysis", "competitive advantage", "business planning"
    ],
    duration: "5-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Recognizing and questioning assumptions and constraints",
      "Identifying and capitalizing on opportunities",
      "Creating innovative value propositions",
      "Discovering new market positions for competitive advantage"
    ],
    targetAudience: "Aspiring entrepreneurs, business leaders, and professionals in dynamic, uncertain business environments"
  },
  "Financial Management": {
    keywords: [
      "finance", "accounting", "investment", "corporate finance",
      "financial analysis", "portfolio", "risk management", "budgeting",
      "financial planning", "cash flow", "capital markets"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Financial accounting fundamentals",
      "Investment strategies",
      "Corporate finance principles",
      "Evaluation of major strategic corporate and investment decisions"
    ],
    targetAudience: "Finance professionals, managers involved in financial decision-making, or those seeking to enhance their financial acumen"
  },
  "Global Challenges in Business": {
    keywords: [
      "global", "international", "cross-cultural", "multinational",
      "global markets", "international trade", "global strategy",
      "emerging markets", "global operations", "international business"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Business strategy formulation and implementation in the global arena",
      "Emerging markets",
      "Social media's impact on global business",
      "Technological advancements in international business"
    ],
    targetAudience: "Professionals working in or aspiring to roles in international business or global strategy"
  },
  "Managerial Economics & Business Analysis": {
    keywords: [
      "economics", "analysis", "market research", "forecasting",
      "business strategy", "decision-making", "market analysis",
      "economic analysis", "quantitative analysis", "business intelligence"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Market operations",
      "Macro-economic environment assessment",
      "Analytical framework development for business decisions"
    ],
    targetAudience: "Managers, business analysts, and professionals seeking to enhance their economic analysis and decision-making skills"
  },
  "Mergers & Acquisitions": {
    keywords: [
      "m&a", "investment banking", "corporate finance", "valuation",
      "due diligence", "deal structure", "negotiation", "private equity",
      "transaction advisory", "corporate strategy"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Financial accounting and finance for complex organizations",
      "Deal structures and transactions",
      "Real-life investment banking case simulations"
    ],
    targetAudience: "Finance professionals, investment bankers, or those interested in corporate strategy and M&A"
  },
  "Strategic Leadership & Management": {
    keywords: [
      "leadership", "management", "strategy", "organizational behavior",
      "team management", "change management", "strategic planning",
      "executive leadership", "performance management", "talent development"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Frameworks and tools for effective leadership",
      "Strategy shaping",
      "Performance elevation of individuals and teams"
    ],
    targetAudience: "Current or aspiring managers and leaders looking to enhance their strategic and leadership skills"
  },
  "Value Chain Management": {
    keywords: [
      "supply chain", "operations", "logistics", "procurement",
      "inventory management", "process improvement", "quality management",
      "lean", "six sigma", "operations management"
    ],
    duration: "8-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "Financial and non-financial accounting for strategic performance measurement",
      "Operations management and process improvement",
      "Marketing elements and their interaction for value creation"
    ],
    targetAudience: "Operations managers, supply chain professionals, and those interested in understanding and optimizing organizational value creation"
  },
  "Taxation": {
    keywords: [
      "tax", "accounting", "irs", "tax planning", "tax compliance",
      "corporate tax", "international tax", "tax law", "tax preparation",
      "tax research", "state tax", "federal tax"
    ],
    duration: "12-24 months",
    format: "100% online",
    timeCommitment: "10-15 hours/week per course",
    topics: [
      "U.S. federal tax system for individuals, employees, and sole proprietors",
      "U.S. federal income tax treatment of corporations and pass-through entities",
      "State and local income tax laws prevalent in the U.S.",
      "Tax treatment, issues, planning techniques, and policies for international business"
    ],
    targetAudience: "Accounting professionals, tax specialists, or those seeking to specialize in taxation"
  }
} as const;