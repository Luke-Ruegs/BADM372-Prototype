export const programs = {
  "Master of Accounting Science (MAS)": {
    keywords: [
      "accounting", "audit", "tax", "cpa", "financial reporting", "assurance",
      "data analytics", "financial statements", "forensic", "compliance",
      "advanced financial reporting", "tax planning", "auditing", "ethics",
      "leadership", "critical thinking", "problem solving", "teamwork",
      "financial analysis", "business intelligence", "risk management"
    ],
    duration: "9 months",
    startDates: ["August", "January"],
    requirements: "BS in Accountancy from US-accredited institution required",
    careers: [
      "Certified Public Accountant (CPA)",
      "Financial Analyst",
      "Tax Specialist",
      "Auditor",
      "Forensic Accountant",
      "Corporate Financial Manager",
      "Accounting Information Systems Specialist",
      "Data Analytics Accountant",
      "Business Intelligence Analyst",
      "Risk Management Specialist"
    ],
    description: "Develop data analytics skills to become a leader in accounting and prepare for the CPA exam with confidence.",
    coreCourses: [
      "Financial Reporting & Assurance (FRA)",
      "Taxation",
      "Data analytics in accounting",
      "Graduate electives (12 credit hours)"
    ]
  },
  "MS in Accountancy (MSA)": {
    keywords: [
      "accounting", "audit", "tax", "financial reporting", "managerial accounting",
      "data analytics", "risk management", "statistical analysis", "ethics",
      "financial analysis", "auditing", "taxation", "corporate finance",
      "process management", "leadership", "critical thinking"
    ],
    duration: "12 months",
    startDates: ["June"],
    requirements: "All majors welcome, no US accounting degree required",
    careers: [
      "Certified Public Accountant (CPA)",
      "Auditor",
      "Tax Specialist",
      "Financial Analyst",
      "Management Accountant",
      "Forensic Accountant",
      "Corporate Financial Manager",
      "Accounting Information Systems Specialist",
      "Consultant"
    ],
    description: "Build expertise in accounting fundamentals and prepare for the CPA Exam.",
    coreCourses: [
      "Accounting Analysis I and II",
      "Auditing",
      "Federal Taxation",
      "Managerial Accounting",
      "Process Management or Advanced Corporate Finance"
    ],
    concentrations: [
      "Data Analytics in Accountancy",
      "Taxation",
      "Corporate Governance & International Business",
      "Finance",
      "Information Technology & Control",
      "Supply Chain Management"
    ]
  },
  "MS in Business Analytics (MSBA)": {
    keywords: [
      "data analytics", "statistics", "python", "sql", "visualization",
      "machine learning", "business intelligence", "predictive modeling",
      "data management", "statistical analysis", "data visualization",
      "data-driven decision making", "consulting", "project management",
      "strategic thinking", "problem solving", "communication"
    ],
    duration: "9 months",
    startDates: ["August"],
    requirements: "All majors welcome",
    careers: [
      "Data Analyst",
      "Business Intelligence Analyst",
      "Data-Driven Decision Maker",
      "Business Analytics Consultant",
      "Data Scientist",
      "Marketing Analyst",
      "Operations Analyst",
      "Financial Analyst",
      "Supply Chain Analyst"
    ],
    description: "Learn to lead, innovate, and solve business problems by leveraging business analytics methods and tools.",
    coreCourses: [
      "Data gathering and management",
      "Data analysis",
      "Data communication",
      "Business decision-making using data",
      "Client-based projects"
    ]
  },
  "MS in Finance (MSF)": {
    keywords: [
      "finance", "investment", "portfolio", "trading", "financial analysis",
      "markets", "fintech", "quantitative", "risk management", "asset management",
      "corporate finance", "data analytics", "financial modeling",
      "investment strategies", "strategic decision-making"
    ],
    duration: "15 months",
    startDates: ["August", "January"],
    requirements: "All majors welcome",
    careers: [
      "Financial Analyst",
      "Investment Banker",
      "Portfolio Manager",
      "Risk Manager",
      "Corporate Finance Specialist",
      "Quantitative Analyst",
      "Financial Consultant",
      "Fintech Specialist",
      "Asset Manager",
      "Financial Researcher"
    ],
    description: "A flexible, practical program providing strong foundation in finance principles and practices.",
    specializations: [
      "Asset Management",
      "Corporate Finance",
      "Data Analytics and Fintech",
      "Quantitative Finance",
      "Finance Research (PhD Specialization)"
    ]
  },
  "MS in Financial Engineering (MSFE)": {
    keywords: [
      "quantitative finance", "data analytics", "machine learning", "optimization",
      "neural networks", "deep learning", "risk management", "financial modeling",
      "python", "R", "programming", "algorithms", "derivatives", "trading",
      "financial mathematics", "stochastic calculus"
    ],
    duration: "15 months",
    startDates: ["August"],
    requirements: "Strong quantitative background required",
    careers: [
      "Quantitative Analyst",
      "Financial Engineer",
      "Risk Manager",
      "Algorithmic Trader",
      "Financial Data Scientist",
      "Derivatives Trader",
      "Financial Software Developer",
      "Financial Modeler",
      "Investment Strategist"
    ],
    description: "Master quantitative methods and their applications in the financial industry.",
    coreCourses: [
      "Quantitative finance techniques",
      "Data analytics and machine learning",
      "Optimization methods",
      "Neural networks and deep learning",
      "Risk measurement and management",
      "Financial modeling and analysis"
    ]
  },
  "MS in Management (MSM)": {
    keywords: [
      "management", "leadership", "business", "strategy", "project management",
      "business analysis", "data analytics", "finance", "marketing",
      "global business", "strategic thinking", "problem solving",
      "data-driven decision making", "project coordination"
    ],
    duration: "9 months",
    startDates: ["August"],
    requirements: "Non-business majors preferred",
    careers: [
      "Business Analyst",
      "Marketing Coordinator",
      "Project Manager",
      "Strategy Consultant",
      "Tech Consultant"
    ],
    description: "Learn fundamental management skills with specializations in data analytics, marketing, global business, and finance.",
    concentrations: [
      "Data Analytics",
      "Finance",
      "Marketing",
      "Global Business",
      "Management"
    ]
  },
  "MS in Technology Management (MSTM)": {
    keywords: [
      "technology management", "innovation", "digital transformation",
      "project management", "IT strategy", "leadership", "entrepreneurship",
      "business analysis", "strategic technology", "change management",
      "digital innovation", "technology implementation"
    ],
    duration: "12 months",
    startDates: ["August"],
    requirements: "All majors welcome",
    careers: [
      "Technology Project Manager",
      "Innovation Manager",
      "Business Analyst",
      "Product Manager",
      "Technology Consultant",
      "Digital Transformation Specialist",
      "IT Strategy Manager",
      "Technology Operations Manager"
    ],
    description: "Develop skills to manage technological change and enhance business performance.",
    coreCourses: [
      "Innovation management",
      "Strategic technology implementation",
      "Business problem-solving",
      "Leadership in technology-driven environments",
      "Project management"
    ]
  }
} as const;