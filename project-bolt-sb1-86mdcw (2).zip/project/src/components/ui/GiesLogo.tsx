import { cn } from '@/lib/utils';

interface GiesLogoProps {
  className?: string;
}

export function GiesLogo({ className }: GiesLogoProps) {
  return (
    <svg
      viewBox="0 0 800 190"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("w-48", className)}
    >
      <path
        d="M0 185V5h65.2c38.4 0 57.6 19.2 57.6 48.8 0 20.8-11.2 35.2-28 41.6 20 4.8 33.6 20.8 33.6 44 0 32-22.4 45.6-59.2 45.6H0zm56.8-108h4c16.8 0 24-8 24-20.8 0-12-7.2-19.2-24-19.2h-4v40zm0 76h8c18.4 0 26.4-8 26.4-22.4 0-13.6-8-21.6-26.4-21.6h-8v44z"
        fill="currentColor"
      />
      <path
        d="M229.6 188c-44 0-72-28.8-72-92.8C157.6 32 185.6 2.4 229.6 2.4c44 0 72 29.6 72 92.8 0 64-28 92.8-72 92.8zm0-32c20.8 0 32-16.8 32-60.8 0-44-11.2-60.8-32-60.8-20.8 0-32 16.8-32 60.8 0 44 11.2 60.8 32 60.8z"
        fill="currentColor"
      />
      <path
        d="M392.8 188c-44 0-72-28.8-72-92.8C320.8 32 348.8 2.4 392.8 2.4c44 0 72 29.6 72 92.8 0 64-28 92.8-72 92.8zm0-32c20.8 0 32-16.8 32-60.8 0-44-11.2-60.8-32-60.8-20.8 0-32 16.8-32 60.8 0 44 11.2 60.8 32 60.8z"
        fill="currentColor"
      />
      <path
        d="M488 185V5h60v148h76v32H488z"
        fill="currentColor"
      />
    </svg>
  );
}