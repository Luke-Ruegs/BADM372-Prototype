import { cn } from '@/lib/utils';

interface IllinoisLogoProps {
  className?: string;
}

export function IllinoisLogo({ className }: IllinoisLogoProps) {
  return (
    <svg
      viewBox="0 0 142 196"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("w-12 h-16", className)}
    >
      <path
        d="M0 0H142V31.36H87.72V164.64H142V196H0V164.64H54.28V31.36H0V0Z"
        fill="currentColor"
      />
    </svg>
  );
}