import { Clock, BookOpen, Users, Laptop, CheckCircle2, LightbulbIcon, Target, Briefcase, GraduationCap, Globe } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { CertificateRecommendation } from '@/lib/utils/analyzeResume';

interface CertificateCardProps {
  recommendation: CertificateRecommendation;
  index: number;
}

export function CertificateCard({ recommendation: rec, index }: CertificateCardProps) {
  // Split personalized reason into sections for better presentation
  const reasons = rec.personalizedReason.split('. ').filter(Boolean);

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className={`h-2 ${index === 0 ? 'bg-[#E84A27]' : 'bg-[#1E3877]'}`} />
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-bold text-[#1E3877]">{rec.name}</CardTitle>
          <span
            className={cn(
              "px-3 py-1 rounded-full text-sm font-medium",
              rec.confidence >= 80
                ? "bg-green-100 text-green-800"
                : rec.confidence >= 60
                ? "bg-[#E84A27]/10 text-[#E84A27]"
                : "bg-gray-100 text-gray-800"
            )}
          >
            {rec.confidence}% Match
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Enhanced Personalized Recommendation */}
        <div className="bg-gradient-to-br from-[#E84A27]/5 to-[#1E3877]/5 p-6 rounded-xl border border-[#E84A27]/10">
          <div className="flex items-center gap-2 mb-4">
            <LightbulbIcon className="h-5 w-5 text-[#E84A27]" />
            <h3 className="font-semibold text-[#1E3877]">Why This Certificate Is Perfect for You</h3>
          </div>
          <div className="space-y-4">
            {reasons.map((reason, idx) => {
              // Determine which icon to show based on the content
              let Icon = Target;
              if (reason.toLowerCase().includes('experience')) {
                Icon = Briefcase;
              } else if (reason.toLowerCase().includes('education') || reason.toLowerCase().includes('academic')) {
                Icon = GraduationCap;
              } else if (reason.toLowerCase().includes('international') || reason.toLowerCase().includes('global')) {
                Icon = Globe;
              }

              return (
                <div key={idx} className="flex gap-3 items-start group">
                  <div className="mt-1">
                    <Icon className="h-4 w-4 text-[#E84A27] group-hover:scale-110 transition-transform" />
                  </div>
                  <p className="text-sm leading-relaxed text-gray-700">
                    {reason}.
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Why This Certificate Matches */}
        <div className="space-y-2 bg-[#1E3877]/5 p-4 rounded-lg">
          <p className="text-sm font-medium text-[#1E3877] flex items-center">
            <CheckCircle2 className="h-4 w-4 mr-2 text-[#E84A27]" />
            Key Matches With Your Profile
          </p>
          <ul className="text-sm space-y-2">
            {rec.matchExplanations.map((explanation, i) => (
              <li key={i} className="flex items-start">
                <span className="text-[#E84A27] mr-2">•</span>
                <span>{explanation}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-[#E84A27]" />
            <span className="text-sm">{rec.duration}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Laptop className="h-5 w-5 text-[#E84A27]" />
            <span className="text-sm">{rec.format}</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-[#E84A27]" />
            <span className="text-sm">{rec.timeCommitment}</span>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-600 flex items-center">
            <BookOpen className="h-4 w-4 text-[#E84A27] mr-2" />
            Topics Covered
          </p>
          <ul className="text-sm space-y-1 list-disc list-inside ml-2">
            {rec.topics.map((topic, i) => (
              <li key={i}>{topic}</li>
            ))}
          </ul>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-600 flex items-center">
            <Users className="h-4 w-4 text-[#E84A27] mr-2" />
            Who Should Take It
          </p>
          <p className="text-sm">{rec.targetAudience}</p>
        </div>
      </CardContent>
    </Card>
  );
}