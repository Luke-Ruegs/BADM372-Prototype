import { useState, useCallback } from 'react';
import { Upload, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { parseFile } from '@/lib/utils/fileParser';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface FileUploadProps {
  onFileUpload: (content: string) => void;
  onError: (message: string) => void;
}

export function FileUpload({ onFileUpload, onError }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<{ title: string; description: string } | null>(null);

  const handleFile = useCallback(async (file: File) => {
    setIsProcessing(true);
    setError(null);

    try {
      const content = await parseFile(file);
      onFileUpload(content);
    } catch (err) {
      let title = 'Error Processing File';
      let description = 'An unexpected error occurred while processing your file.';

      if (err instanceof Error) {
        title = err.message;
        description = 'details' in err ? (err as any).details || err.message : err.message;
      }

      setError({ title, description });
      onError(title);
    } finally {
      setIsProcessing(false);
    }
  }, [onFileUpload, onError]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      await handleFile(file);
    }
  }, [handleFile]);

  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      await handleFile(file);
    }
  }, [handleFile]);

  return (
    <div className="space-y-4">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          "border-2 border-dashed rounded-xl p-8 transition-colors",
          isDragging
            ? "border-[#E84A27] bg-[#E84A27]/5"
            : error
              ? "border-red-300 hover:border-red-400"
              : "border-[#1E3877]/20 hover:border-[#1E3877]/40"
        )}
      >
        <label className="cursor-pointer block text-center">
          {isProcessing ? (
            <Loader2 className="mx-auto h-12 w-12 text-[#1E3877] mb-4 animate-spin" />
          ) : error ? (
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
          ) : (
            <Upload className="mx-auto h-12 w-12 text-[#1E3877] mb-4" />
          )}
          <span className="block text-lg font-medium text-[#1E3877] mb-2">
            {isProcessing 
              ? 'Processing your resume...' 
              : isDragging 
                ? 'Drop your resume here' 
                : 'Upload your resume'}
          </span>
          <span className="text-sm text-gray-500">
            {isProcessing 
              ? 'This may take a moment'
              : 'Drag and drop or click to browse (TXT, PDF, DOC, DOCX)'}
          </span>
          <input
            type="file"
            className="hidden"
            accept=".txt,.pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
            onChange={handleFileChange}
            disabled={isProcessing}
          />
        </label>
      </div>

      {error && (
        <Alert variant="destructive" className="bg-red-50 border-red-200">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle className="text-red-800 font-medium">{error.title}</AlertTitle>
          <AlertDescription className="text-red-700">{error.description}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}