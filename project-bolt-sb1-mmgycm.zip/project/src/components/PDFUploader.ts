export class PDFUploader {
  private fileInput: HTMLInputElement;
  private container: HTMLDivElement;

  constructor(containerId: string) {
    this.container = document.createElement('div');
    this.container.className = 'pdf-uploader';
    
    this.fileInput = document.createElement('input');
    this.fileInput.type = 'file';
    this.fileInput.accept = '.pdf';
    this.fileInput.className = 'pdf-input';
    
    const label = document.createElement('p');
    label.textContent = 'Select a PDF file to parse:';
    
    this.container.appendChild(label);
    this.container.appendChild(this.fileInput);
    
    const targetContainer = document.getElementById(containerId);
    if (targetContainer) {
      targetContainer.appendChild(this.container);
    }
  }

  onFileSelect(callback: (file: File) => void) {
    this.fileInput.addEventListener('change', (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        callback(file);
      }
    });
  }
}