export function createUploadUI(): void {
  document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
    <div class="container">
      <h1>Program Recommendation System</h1>
      <p>Upload your resume in PDF format to get a program recommendation:</p>
      <div class="upload-area" id="dropZone">
        <input type="file" id="fileInput" accept=".pdf" style="display: none;">
        <div class="upload-content">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="17 8 12 3 7 8"/>
            <line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
          <p>Drag & drop your PDF resume here<br>or click to browse</p>
        </div>
      </div>
      <div id="fileName" class="file-name"></div>
      <div id="loading" class="loading" style="display: none;">
        <div class="spinner"></div>
        <p>Analyzing resume...</p>
      </div>
      <div id="result" class="result" style="display: none;"></div>
    </div>
  `;
}

export function showError(message: string): void {
  const resultDiv = document.querySelector<HTMLDivElement>('#result')!;
  resultDiv.innerHTML = `<p class="error">${message}</p>`;
  resultDiv.style.display = 'block';
  document.querySelector<HTMLDivElement>('#loading')!.style.display = 'none';
}

export function showResult(program: string, explanation: string): void {
  const resultDiv = document.querySelector<HTMLDivElement>('#result')!;
  resultDiv.innerHTML = `
    <h2>Recommendation</h2>
    <p><strong>Recommended Program:</strong> ${program}</p>
    <p><strong>Explanation:</strong> ${explanation}</p>
  `;
  resultDiv.style.display = 'block';
  document.querySelector<HTMLDivElement>('#loading')!.style.display = 'none';
}

export function showLoading(): void {
  document.querySelector<HTMLDivElement>('#loading')!.style.display = 'flex';
  document.querySelector<HTMLDivElement>('#result')!.style.display = 'none';
}