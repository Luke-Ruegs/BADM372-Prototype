interface ProgramData {
  keywords: string[];
  professional_outcomes: string[];
}

interface ProgramKeywords {
  [key: string]: ProgramData;
}

const PROGRAM_KEYWORDS: ProgramKeywords = {
  "MAS": {
    keywords: ["financial reporting", "tax compliance", "data analytics in accounting", "CPA", "auditing", "financial statement analysis"],
    professional_outcomes: ["Certified Public Accountant", "Financial Analyst", "Auditor", "Forensic Accountant"]
  },
  "MSA": {
    keywords: ["accounting analysis", "auditing", "federal taxation", "managerial accounting", "CPA preparation", "risk management"],
    professional_outcomes: ["Auditor", "Tax Specialist", "Management Accountant", "Forensic Accountant"]
  },
  "MSBA": {
    keywords: ["data analysis", "predictive modeling", "data visualization", "machine learning", "SQL", "business intelligence"],
    professional_outcomes: ["Data Analyst", "Business Intelligence Analyst", "Data Scientist", "Marketing Analyst"]
  },
  "MSF": {
    keywords: ["financial modeling", "investment analysis", "corporate finance", "fintech", "quantitative analysis"],
    professional_outcomes: ["Financial Analyst", "Investment Banker", "Portfolio Manager", "Risk Manager"]
  },
  "MSFE": {
    keywords: ["quantitative finance", "data analytics", "machine learning", "financial engineering", "programming"],
    professional_outcomes: ["Quantitative Analyst", "Algorithmic Trader", "Financial Engineer"]
  },
  "MSM": {
    keywords: ["project management", "business analysis", "marketing", "strategic thinking", "finance", "global business"],
    professional_outcomes: ["Business Analyst", "Marketing Coordinator", "Project Manager"]
  },
  "MSTM": {
    keywords: ["technology management", "project management", "innovation", "entrepreneurship", "product management"],
    professional_outcomes: ["Technology Project Manager", "Innovation Manager", "IT Strategy Manager"]
  }
};

interface MatchResult {
  program: string;
  explanation: string;
}

export function matchProgram(resumeText: string): MatchResult {
  const programScores = new Map<string, number>();
  const lowerText = resumeText.toLowerCase();

  for (const [program, data] of Object.entries(PROGRAM_KEYWORDS)) {
    let score = 0;
    for (const keyword of data.keywords) {
      if (lowerText.includes(keyword.toLowerCase())) {
        score += 1;
      }
    }
    programScores.set(program, score);
  }

  let bestMatch = Array.from(programScores.entries()).reduce((a, b) => 
    b[1] > a[1] ? b : a
  )[0];

  const matchedKeywords = PROGRAM_KEYWORDS[bestMatch].keywords.filter(keyword => 
    lowerText.includes(keyword.toLowerCase())
  );

  const explanation = matchedKeywords.length > 0 
    ? `The ${bestMatch} program is recommended because your resume matches several key skills such as ${matchedKeywords.join(', ')}. This program will help enhance your qualifications for roles like ${PROGRAM_KEYWORDS[bestMatch].professional_outcomes.join(', ')}.`
    : `The ${bestMatch} program is recommended based on the overall content of your resume. This program will help prepare you for roles like ${PROGRAM_KEYWORDS[bestMatch].professional_outcomes.join(', ')}.`;

  return { program: bestMatch, explanation };
}