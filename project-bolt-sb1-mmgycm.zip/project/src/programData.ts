import { ProgramKeywords } from './types';

export const PROGRAM_KEYWORDS: ProgramKeywords = {
  MAS: {
    keywords: ["financial reporting", "tax compliance", "data analytics in accounting", "cpa", "auditing", "financial statement analysis"],
    professional_outcomes: ["Certified Public Accountant", "Financial Analyst", "Auditor", "Forensic Accountant"]
  },
  MSA: {
    keywords: ["accounting analysis", "auditing", "federal taxation", "managerial accounting", "cpa preparation", "risk management"],
    professional_outcomes: ["Auditor", "Tax Specialist", "Management Accountant", "Forensic Accountant"]
  },
  MSBA: {
    keywords: ["data analysis", "predictive modeling", "data visualization", "machine learning", "sql", "business intelligence"],
    professional_outcomes: ["Data Analyst", "Business Intelligence Analyst", "Data Scientist", "Marketing Analyst"]
  },
  MSF: {
    keywords: ["financial modeling", "investment analysis", "corporate finance", "fintech", "quantitative analysis"],
    professional_outcomes: ["Financial Analyst", "Investment Banker", "Portfolio Manager", "Risk Manager"]
  },
  MSFE: {
    keywords: ["quantitative finance", "data analytics", "machine learning", "financial engineering", "programming"],
    professional_outcomes: ["Quantitative Analyst", "Algorithmic Trader", "Financial Engineer"]
  },
  MSM: {
    keywords: ["project management", "business analysis", "marketing", "strategic thinking", "finance", "global business"],
    professional_outcomes: ["Business Analyst", "Marketing Coordinator", "Project Manager"]
  },
  MSTM: {
    keywords: ["technology management", "project management", "innovation", "entrepreneurship", "product management"],
    professional_outcomes: ["Technology Project Manager", "Innovation Manager", "IT Strategy Manager"]
  }
};