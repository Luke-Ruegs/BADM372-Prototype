export interface ProgramData {
  keywords: string[];
  professional_outcomes: string[];
}

export interface ProgramKeywords {
  [key: string]: ProgramData;
}

export interface ProgramMatch {
  program: string;
  explanation: string;
}